package codegen.symboltable;

public enum BlockType {
    ROOT,
    METHOD,
    CONDITION,
    LOOP,
}
