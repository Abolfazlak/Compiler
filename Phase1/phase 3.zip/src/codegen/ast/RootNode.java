package codegen.ast;

public class RootNode extends SimpleNode {
    public RootNode() {
        super(NodeType.START);
    }
}
